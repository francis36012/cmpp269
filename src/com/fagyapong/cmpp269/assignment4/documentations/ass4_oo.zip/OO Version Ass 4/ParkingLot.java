
/**
/**
 * Purpose: 
 * Input:
 *
 * Processing done:
 *
 * Output:
 *
 * @author (your name) 
 * @version (a version number or a date)
 */

import java.util.ArrayList;
import java.io.*;
import java.util.*;
// make this class Serializable and its dependent classes (Car)
public class ParkingLot 
{
    private ArrayList<Car> parkingLot;
    private static String plateListFile = "c:/temp/plateList.txt";
    private static String ccReport = "c:/temp/ccReport.txt";
    private static double charge = 4.00;
    private Car x;
    // Constructor
    public ParkingLot () throws IOException, ClassNotFoundException {
        // SET UP THE ARRAYLIST parkingLot
    }

    // returns the number of cars in the parkingLot
    public int numCars() {
        // FILL IN CODE HERE
        return 0;
    }
    // Add a car to the parking lot
    public void addCar(Car newCar) {
        // ADD newCar to the arraylist here
    }

    // return the Car info from a plate, return null if not found
    public Car findCar (String plate){
        Car result;
        result = null;

        boolean isCarFound = false;

        // transverse the list looking for the plate
        // LOOP TO TRANSVERSE THE ARRAYLIST
        // return pointer to Car object or null if not found
        return result;
    }
    // create the daily charges report
    public  void printCharges () throws IOException {
        // WRITE CODE HERE
    }
    // create the list of plates registered in the parking lot
    public void plateList () throws IOException {
        // WRITE CODE HERE
    }

}